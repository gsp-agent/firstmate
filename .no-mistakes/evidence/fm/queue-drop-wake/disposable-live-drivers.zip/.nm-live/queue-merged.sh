#!/usr/bin/env bash
set -eu
. "$PWD/bin/fm-wake-lib.sh"
fm_wake_append check "$FM_HOME/state/task-a.check.sh" "check: $FM_HOME/state/task-a.check.sh: merged"
