import hashlib
import json
import subprocess
from pathlib import Path
import guard_final_support as d

def rewrite(path, lines):
    # Deliberately keep the inode: this models a recorded volume identity
    # changing, and the interrupted rewrite's already-updated check object.
    path.write_text('\n'.join(lines)+'\n')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def shift_registration(path):
    lines=path.read_text().splitlines()
    for i in [9,10]:
        device,inode=lines[i].split(':')
        lines[i]=str(int(device)+1)+':'+inode
    rewrite(path,lines)

def recover_template(variant):
    h=d.create('template-'+variant)
    repo='lab/template'
    d.WORLD.repos[repo]={1:d.node(1,'failed_checks','evt-template')}
    old=d.LAB/'shipped-poll.sh'
    old.write_bytes(subprocess.check_output(['git','show','38fa6f7bde25e4cd64235581ceb16ca92a8453bc:bin/fm-pr-poll.sh'],cwd=d.ROOT))
    current=d.ROOT/'bin/fm-pr-poll.sh'
    d.seed(h,'task-a',repo,1,current if variant.startswith('unshipped') else old)
    reg=h/'state/task-a.pr-poll-registration'
    check=h/'state/task-a.check.sh'
    if variant in ['renumbered','interrupted-renumbered','tampered','unshipped-renumbered']:
        shift_registration(reg)
    if variant=='interrupted-renumbered':
        check.write_bytes(current.read_bytes())
    if variant=='tampered':
        with check.open('a') as f:f.write('\n# changed outside authenticated template\n')
    if variant.startswith('unshipped'):
        lines=reg.read_text().splitlines(); lines[8]='f'*64; rewrite(reg,lines)
    before_reg=digest(reg); before_check=digest(check)
    out=d.watch(h).stdout
    polled=[r for r in d.WORLD.requests if r['type']=='poll']
    if variant in ['tampered','unshipped','unshipped-renumbered']:
        assert 'rejected unauthenticated state checks:' in out
        assert not polled
        assert digest(reg)==before_reg and digest(check)==before_check
        d.passed('A '+variant+' watch is rejected without polling or rewriting its authenticated artifacts')
    else:
        d.has_drop(out,repo,1,'failed_checks'); d.has_drop(d.drain(h),repo,1,'failed_checks')
        assert len(polled)==1
        lines=reg.read_text().splitlines()
        assert lines[8]==digest(current)
        for i,path in [(9,h/'state/task-a.pr-poll'),(10,check)]:
            st=path.stat(); assert lines[i]==f'{st.st_dev}:{st.st_ino}'
        assert digest(check)==digest(current)
        d.emit('PERSISTED RESULT: current template hash and both live device/inode identities were recorded together.')
        # Confirm it remains a functioning merge watch on the following poll.
        d.WORLD.repos[repo][1]=d.node(1,state='MERGED')
        assert 'task-a.check.sh: merged' in d.watch(h).stdout
        d.drain(h)
        assert sum(r['type']=='poll' for r in d.WORLD.requests)==2
        d.passed('A '+variant+' shipped-template watch recovers, delivers its removal, and keeps polling through merge')
    d.save_requests('template-'+variant)

def boundary_calls(h):
    before={p.name:(p.read_bytes(),p.stat().st_ino) for p in (h/'state').glob('task-a.*') if p.is_file()}
    for command in [['bin/fm-pr-check.sh','task-a','https://github.com/other/repo/pull/3'],
                    ['bin/fm-teardown.sh','task-a']]:
        p=d.run(h,command,check=False)
        assert p.returncode!=0 and 'pending repository merge-queue sweep; preserving task state' in p.stderr
    after={p.name:(p.read_bytes(),p.stat().st_ino) for p in (h/'state').glob('task-a.*') if p.is_file()}
    assert before==after
    d.emit('PERSISTED RESULT: cleanup and cross-repository re-arm both refused at the shared sweep boundary; task artifacts retained byte-for-byte.')

def cleanup_before_observation():
    h=d.create('unobserved-merge-boundary')
    repo='lab/boundary'
    d.WORLD.repos[repo]={1:d.node(1,state='MERGED'),2:d.node(2,'failed_checks','evt-boundary')}
    d.seed(h,'task-a',repo,1)
    assert not (h/'state/task-a.pr-poll-retirement').exists()
    boundary_calls(h)
    d.has_drop(d.watch(h).stdout,repo,2,'failed_checks')
    d.has_drop(d.drain(h),repo,2,'failed_checks')
    assert not (h/'state/task-a.pr-poll').exists()
    d.passed('Cleanup and cross-repository replacement before the watcher observes a merge retain discovery until the unarmed drop is delivered')
    d.save_requests('unobserved-boundary')

def shift_retirement(h):
    reg=h/'state/task-a.pr-poll-registration'
    if reg.exists(): shift_registration(reg)
    receipt=h/'state/task-a.pr-poll-retirement'
    lines=receipt.read_text().splitlines()
    for i in [9,10,12]:
        device,inode=lines[i].split(':'); lines[i]=str(int(device)+1)+':'+inode
    if reg.exists():lines[11]=digest(reg)
    rewrite(receipt,lines)

def retained_receipt(stage):
    h=d.create('receipt-'+stage)
    repo='lab/receipt'
    d.WORLD.repos[repo]={1:d.node(1,state='MERGED'),2:d.node(2,'failed_checks','evt-receipt')}
    d.seed(h,'task-a',repo,1)
    d.run(h,['bash','.nm-live/receipt.sh',stage],log=False)
    if stage=='registration':
        target=h/'state/task-a.check.sh'
        target.read_bytes()
        p=d.run(h,['dcg','test','rm -f -- '+str(target)],check=False,log=False)
        assert p.returncode==0
        d.run(h,['rm','-f','--',target],log=False)
    shift_retirement(h)
    if stage=='sidecar':
        boundary_calls(h)
        d.WORLD.fail_repos.add(repo)
        assert 'rejected unauthenticated PR poll retirement' not in d.watch(h).stdout
        d.drain(h)
        assert (h/'state/task-a.pr-poll').exists()
        d.WORLD.fail_repos.clear()
    # A prior merged notification was durable when the process interrupted.
    # Exercise startup resurface, acknowledge, then scan on the next start.
    if stage=='full':
        d.run(h,['bash','.nm-live/queue-merged.sh'],log=False)
        out=d.watch(h).stdout
        assert 'check: rearm-resurface' in out
        assert (h/'state/task-a.pr-poll').exists()
        d.drain(h)
    out=d.watch(h).stdout
    assert 'rejected unauthenticated PR poll retirement' not in out
    d.has_drop(out,repo,2,'failed_checks');d.has_drop(d.drain(h),repo,2,'failed_checks')
    for suffix in ['check.sh','pr-poll','pr-poll-registration','pr-poll-retirement']:
        assert not (h/('state/task-a.'+suffix)).exists()
    d.passed('A renumbered '+stage+' retirement retains discovery through recovery and removes exactly the authenticated artifacts after delivering the drop')
    d.save_requests('receipt-'+stage)

def slow_custom():
    h=d.create('slow-custom')
    repo='lab/custom'
    d.WORLD.repos[repo]={1:d.node(1,'failed_checks','evt-custom')}
    d.seed(h,'task-final',repo,1)
    for i in range(8):
        p=h/f'state/a{i}.check.sh'
        p.write_text('#!/usr/bin/env bash\nsleep 1\n')
        p.chmod(0o700)
        d.run(h,['bin/fm-check-register.sh','a'+str(i)],log=False)
    extra={'FM_CHECK_TIMEOUT':'10','FM_WATCHER_STALE_GRACE':'4','FM_WATCHER_STALL_BOUND':'4'}
    armed=[]
    def rearm(repo,number):
        p=d.run(h,['bin/fm-watch.sh'],extra=extra,check=False)
        assert p.returncode==0 and 'watcher: already running pid ' in p.stdout+p.stderr
        armed.append(True)
    d.WORLD.poll_hook=rearm
    d.has_drop(d.watch(h,extra=extra).stdout,repo,1,'failed_checks')
    d.has_drop(d.drain(h),repo,1,'failed_checks')
    assert armed
    d.passed('A long prefix of custom checks refreshes liveness at completion and a concurrent re-arm still reaches the final PR removal')
    d.save_requests('slow-custom')

def receipt_guard(mutation):
    h=d.create('final-receipt-guard-'+mutation)
    d.WORLD.repos['lab/guard']={1:d.node(1,state='MERGED')}
    d.seed(h,'task-a','lab/guard',1)
    d.run(h,['bash','.nm-live/receipt.sh','full'],log=False)
    shift_retirement(h)
    data=h/'state/task-a.pr-poll'
    original=data.read_bytes()
    if mutation=='content':
        data.write_bytes(original.replace(b'lab/guard',b'lab/other'))
    else:
        replacement=h/'state/replacement-sidecar'
        replacement.write_bytes(original); replacement.chmod(0o600)
        before_inode=data.stat().st_ino
        d.run(h,['dcg','test','mv -f -- '+str(replacement)+' '+str(data)],log=False)
        d.run(h,['mv','-f','--',replacement,data],log=False)
        assert data.stat().st_ino!=before_inode
    before={p.name:(p.read_bytes(),p.stat().st_ino) for p in (h/'state').glob('task-a.*') if p.is_file()}
    for args in [['bin/fm-pr-check.sh','task-a','https://github.com/other/repo/pull/3'],['bin/fm-teardown.sh','task-a']]:
        p=d.run(h,args,check=False)
        assert p.returncode!=0
        assert 'invalid PR-poll retirement receipt' in p.stderr or 'pending PR poll retirement could not be validated' in p.stderr
    out=d.watch(h).stdout
    assert 'rejected unauthenticated PR poll retirement receipts:' in out
    after={p.name:(p.read_bytes(),p.stat().st_ino) for p in (h/'state').glob('task-a.*') if p.is_file()}
    assert before==after and not d.WORLD.requests
    d.passed('A retained renumbered receipt with changed sidecar '+mutation+' stays refused by re-arm, cleanup and watcher recovery without deleting the sidecar')

try:
    receipt_guard('content')
    receipt_guard('inode')
except Exception as exc:
    d.emit('RECEIPT GUARD FAILURE: '+repr(exc));raise
finally:
    d.SERVER.shutdown();d.SERVER.server_close()
    (d.EVIDENCE/'live-receipt-guard-final-scenarios.json').write_text(json.dumps(d.RESULTS,ensure_ascii=False,indent=2)+'\n')
    d.LOG.close()
