import copy
import http.server
import json
import os
from pathlib import Path
import re
import socketserver
import ssl
import subprocess
import threading
import time

ROOT = Path.cwd()
LAB = ROOT / '.nm-live'
EVIDENCE = Path('/Users/dalecarman/.no-mistakes/evidence/01M51YY81T7RNEF2SS370MNK77')
LOG = (EVIDENCE / 'reason-cli-probe.log').open('w')
RESULTS = []
WORLD = None
CHILDREN = []

def emit(s):
    print(s, flush=True)
    LOG.write(s + '\n')
    LOG.flush()

def node(n, reason=None, event=None, queued=False, state='OPEN', created=None):
    return {'number': n, 'state': state, 'merged': state == 'MERGED',
            'isInMergeQueue': queued, 'createdAt': created or n, 'updatedAt': created or n,
            'isDraft': False, 'headRefOid': 'a' * 40,
            'timelineItems': {'nodes': [] if event is None else [{
                '__typename': 'RemovedFromMergeQueueEvent', 'id': event, 'reason': reason}]}}

class World:
    def __init__(self):
        self.repos = {}
        self.requests = []
        self.fail_repos = set()
        self.fail_cursor = None
        self.page_delay = 0
        self.poll_delay = 0
        self.page_hook = None
        self.poll_hook = None

    def read(self, request):
        q = request.get('query', '')
        v = request.get('variables', {})
        v = {k.lower(): value for k, value in v.items()}
        repo = str(v.get('owner', '')) + '/' + str(v.get('repo', v.get('name', '')))
        if 'pullRequests(' in q:
            cursor = v.get('cursor')
            order = re.search(r'orderBy\s*:\s*\{\s*field\s*:\s*(\w+)\s*,\s*direction\s*:\s*(\w+)', q)
            if order is None:
                raise ValueError('missing pull request order')
            order_field, direction = order.groups()
            record = {'type': 'page', 'repo': repo, 'cursor': cursor, 'order': order_field,
                      'at': time.time()}
            self.requests.append(record)
            if self.page_hook:
                self.page_hook(repo, cursor)
            if self.page_delay:
                time.sleep(self.page_delay)
            if repo in self.fail_repos or (self.fail_cursor is not None and cursor == self.fail_cursor):
                record['status'] = 503
                return 503, {'message': 'disposable endpoint: page unavailable'}
            key = {'CREATED_AT': 'createdAt', 'UPDATED_AT': 'updatedAt'}[order_field]
            pulls = sorted([p for p in self.repos.get(repo, {}).values() if p['state'] == 'OPEN'],
                           key=lambda p: p[key], reverse=direction == 'DESC')
            start = 0 if cursor is None else next(i+1 for i, p in enumerate(pulls) if 'c'+str(p['number']) == cursor)
            count = int(re.search(r'first\s*:\s*(\d+)', q).group(1))
            page = copy.deepcopy(pulls[start:start+count])
            record['numbers'] = [p['number'] for p in page]
            record['status'] = 200
            return 200, {'data': {'repository': {'pullRequests': {
                'nodes': page, 'pageInfo': {'hasNextPage': start + len(page) < len(pulls),
                    'endCursor': 'c'+str(page[-1]['number']) if page else None}}}}}
        if 'pullRequest(' in q:
            number = int(v.get('number', 0))
            record = {'type': 'poll', 'repo': repo, 'number': number, 'at': time.time(), 'status': 200}
            self.requests.append(record)
            if self.poll_hook:
                self.poll_hook(repo, number)
            if self.poll_delay:
                time.sleep(self.poll_delay)
            p = copy.deepcopy(self.repos[repo][number])
            if 'ADDED_TO_MERGE_QUEUE_EVENT' not in q:
                p['timelineItems']['nodes'] = [e for e in p['timelineItems']['nodes']
                    if e['__typename'] == 'RemovedFromMergeQueueEvent'][-1:]
            return 200, {'data': {'repository': {'pullRequest': p}}}
        self.requests.append({'type': 'unexpected', 'query': q})
        return 400, {'message': 'unsupported disposable GraphQL operation'}

TLS = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
TLS.load_cert_chain(str(LAB/'api.crt'), str(LAB/'api.key'))

class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_CONNECT(self):
        if self.path != 'api.github.com:443':
            self.send_error(502, 'this lab only serves api.github.com')
            return
        self.send_response(200, 'Connection established')
        self.end_headers()
        try:
            self.connection = TLS.wrap_socket(self.connection, server_side=True)
            self.rfile = self.connection.makefile('rb')
            self.wfile = self.connection.makefile('wb')
            self.close_connection = False
            self.handle_one_request()
        except (ssl.SSLError, ConnectionError):
            pass
        self.close_connection = True

    def do_POST(self):
        try:
            req = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
            status, data = WORLD.read(req)
        except Exception as exc:
            status, data = 500, {'message': str(exc)}
        payload = json.dumps(data, ensure_ascii=False).encode()
        try:
            self.send_response(status)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(payload)))
            self.send_header('Connection', 'close')
            self.end_headers()
            self.wfile.write(payload)
        except (ConnectionError, ssl.SSLError):
            pass

class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    def handle_error(self, *args):
        pass

SERVER = Server(('127.0.0.1', 0), Handler)
threading.Thread(target=SERVER.serve_forever, daemon=True).start()
PROXY = 'http://127.0.0.1:' + str(SERVER.server_port)

def environment(home):
    e = {k: v for k, v in os.environ.items() if not k.startswith(('FM_', 'GH_', 'GITHUB_', 'HERDR_', 'TASKS_AXI_', 'CMUX_'))
         and k not in ['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY','TMUX','TMUX_TMPDIR']}
    e.update(FM_HOME=str(home), FM_BACKEND='tmux', FM_CHECK_INTERVAL='0', FM_POLL='0.1',
             FM_HEARTBEAT='999999', FM_SIGNAL_GRACE='0',
             GH_CONFIG_DIR=str(LAB/'gh-config'), GH_TOKEN='fm-lab-disposable-no-production-access',
             HTTPS_PROXY=PROXY, HTTP_PROXY=PROXY, NO_PROXY='',
             SSL_CERT_FILE=str(LAB/'api.crt'), TMPDIR=str(LAB/'tmp'),
             TMUX=str(home/'no-server')+',0,0', GIT_CONFIG_GLOBAL='/dev/null', GIT_CONFIG_NOSYSTEM='1')
    return e

def run(home, args, *, check=True, timeout=30, extra=None, log=True):
    e = environment(home)
    if extra:
        e.update(extra)
    p = subprocess.run([str(a) for a in args], cwd=ROOT, env=e,
                       text=True, capture_output=True, timeout=timeout)
    if log:
        emit('$ ' + ' '.join(str(a).replace(str(ROOT)+'/', '') for a in args))
        emit('exit=' + str(p.returncode))
        if p.stdout.strip(): emit(p.stdout.rstrip())
        if p.stderr.strip(): emit(p.stderr.rstrip())
    if check and p.returncode:
        raise AssertionError(f'{args} failed: {p.stderr} {p.stdout}')
    return p

def create(name):
    global WORLD
    WORLD = World()
    home = LAB/name
    run(home, ['bin/fm-lab-home.sh', 'create', home], log=False)
    (home/'config/backend').write_text('tmux\n')
    # This registered check bounds quiet live cycles without replacing any
    # Firstmate code. Its output also proves that the complete check block ran.
    stop = home/'state/zz-lab-cycle.check.sh'
    stop.write_text('#!/usr/bin/env bash\nprintf "lab-cycle-complete\\n"\n')
    stop.chmod(0o700)
    run(home, ['bin/fm-check-register.sh','zz-lab-cycle'], log=False)
    emit('\n=== ' + name + ' ===')
    return home

def seed(home, task, repo, number, template=None):
    args = ['bash','.nm-live/seed-watch.sh',task,repo,str(number)]
    if template: args.append(template)
    run(home,args,log=False)

def watch(home, extra=None, timeout=60):
    return run(home,['bin/fm-watch.sh'],extra=extra,timeout=timeout)

def drain(home, ack=True):
    p = run(home,['bin/fm-wake-drain.sh'])
    if ack:
        m = re.search(r'--ack-through (\d+) --recovery-generation ([A-Za-z0-9._-]+)', p.stderr)
        assert m, 'missing durable acknowledgement command'
        run(home,['bin/fm-wake-drain.sh','--ack-through',m[1],'--recovery-generation',m[2]],log=False)
    return p.stdout

def has_drop(text, repo, number, reason):
    visible = json.dumps(reason or '', ensure_ascii=False)[1:-1]
    expected = f'dequeued https://github.com/{repo}/pull/{number} reason={visible}'
    assert sum(expected in line for line in text.splitlines()) == 1, f'missing or duplicate: {expected}'

def save_requests(name):
    (EVIDENCE/(name+'-api.json')).write_text(json.dumps(WORLD.requests, indent=2)+'\n')

def passed(name):
    RESULTS.append({'name':name,'result':'pass','live':True,'evidence':'live-queue-transcript.log','reason':''})
    emit('OBSERVED: ' + name)

try:
    h=create('reason-cli-probe')
    WORLD.repos={'lab/probe':{1:node(1,'failed "checks"\\path\nnext\tline\rcontrol\x01','evt-probe')}}
    args=['gh','api','graphql','--hostname','github.com','-f','query=query($owner:String!,$repo:String!,$number:Int!){repository(owner:$owner,name:$repo){pullRequest(number:$number){state timelineItems(last:1,itemTypes:[REMOVED_FROM_MERGE_QUEUE_EVENT]){nodes{... on RemovedFromMergeQueueEvent{id reason}}}}}}','-F','owner=lab','-F','repo=probe','-F','number=1']
    raw=run(h,args,log=False)
    emit('Installed gh raw response: '+repr(raw.stdout))
    filtered=run(h,args+['--jq','.data.repository.pullRequest.timelineItems.nodes[0].reason | tojson'],log=False)
    emit('Installed gh --jq tojson response: '+repr(filtered.stdout))
    direct=subprocess.run(['jq','-r','.data.repository.pullRequest.timelineItems.nodes[0].reason | tojson'],input=raw.stdout,text=True,capture_output=True,check=True)
    emit('Installed jq, same raw gh response: '+repr(direct.stdout))
finally:
    SERVER.shutdown();SERVER.server_close();LOG.close()
