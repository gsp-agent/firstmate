#!/usr/bin/env bash
set -eu
. "$PWD/bin/fm-pr-lib.sh"
state=$FM_HOME/state
fm_pr_poll_snapshot_capture "$state" task-a "$PWD/bin/fm-pr-poll.sh"
fm_pr_poll_retirement_publish "$state" task-a "$PWD/bin/fm-pr-poll.sh" merged
if [ "${1:-}" = sidecar ]; then
  fm_pr_poll_retirement_recover_one "$state" task-a "$PWD/bin/fm-pr-poll.sh"
fi
