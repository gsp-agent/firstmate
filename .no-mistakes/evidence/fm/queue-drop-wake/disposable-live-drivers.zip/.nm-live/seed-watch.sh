#!/usr/bin/env bash
set -eu
. "$PWD/bin/fm-pr-lib.sh"
state=$FM_HOME/state
id=$1
repo=$2
number=$3
template=${4:-$PWD/bin/fm-pr-poll.sh}
url="https://github.com/$repo/pull/$number"
printf 'project=lab\nbranch=fm/lab\nmode=direct-PR\nkind=ship\nwindow=fm-lab:fm-%s\nworktree=%s/task-worktree\npr=%s\n' "$id" "$FM_HOME" "$url" > "$state/$id.meta"
chmod 600 "$state/$id.meta"
fm_pr_poll_prepare "$state" "$id" github "$url" github.com "$repo" "$number" "$template"
fm_pr_poll_publish_prepared
