#!/usr/bin/env bash
set -eu
openssl req -x509 -newkey rsa:2048 -nodes -days 1 -keyout .nm-live/api.key -out .nm-live/api.crt -subj /CN=api.github.com -addext subjectAltName=DNS:api.github.com,DNS:github.com,DNS:localhost -addext basicConstraints=critical,CA:TRUE > .nm-live/openssl.log 2>&1
