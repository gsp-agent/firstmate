import http.server
import json
import os
import threading
import time
import relay_support as d

home=None
received=[]
class Relay(http.server.BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_GET(self):
        assert self.path=='/connector/poll'
        stamp=time.time()-1200
        os.utime(home/'state/.last-watcher-beat',(stamp,stamp))
        received.append(self.path)
        d.emit('RELAY INPUT: a real fm-x-poll.sh HTTP request is active; age the existing beacon by 1,200 seconds, then return HTTP 204.')
        self.send_response(204)
        self.end_headers()

relay=http.server.ThreadingHTTPServer(('127.0.0.1',0),Relay)
threading.Thread(target=relay.serve_forever,daemon=True).start()
try:
    home=d.create('relay-liveness')
    repo='lab/relay-liveness'
    d.WORLD.repos[repo]={1:d.node(1,'failed_checks','evt-after-relay')}
    d.seed(home,'y-final',repo,1)
    d.run(home,['bash','.nm-live/seed-relay.sh'],log=False)
    extra={'FMX_PAIRING_TOKEN':'fm-lab-disposable-no-production-access',
           'FMX_RELAY_URL':'http://127.0.0.1:'+str(relay.server_port),
           'FMX_ENV_FILE':str(home/'.env'),
           'NO_PROXY':'127.0.0.1,localhost','no_proxy':'127.0.0.1,localhost'}
    rearmed=[]
    def rearm(repo,number):
        assert received==['/connector/poll']
        age=time.time()-(home/'state/.last-watcher-beat').stat().st_mtime
        d.emit('AFTER REAL RELAY CHECK: beacon age='+str(round(age,3))+' seconds; production stall bound=900 seconds.')
        p=d.run(home,['bin/fm-watch.sh'],extra=extra,timeout=60)
        assert 'watcher: already running pid ' in p.stdout+p.stderr
        rearmed.append(True)
    d.WORLD.poll_hook=rearm
    out=d.watch(home,extra=extra,timeout=180).stdout
    d.has_drop(out,repo,1,'failed_checks')
    d.has_drop(d.drain(home),repo,1,'failed_checks')
    assert rearmed
    d.passed('A real Relay poll renews the expired existing beacon before the next PR check; re-arm keeps the same watcher and the final removal reaches the drain')
    d.save_requests('relay-liveness')
finally:
    relay.shutdown();relay.server_close()
    d.SERVER.shutdown();d.SERVER.server_close()
    (d.EVIDENCE/'live-relay-scenarios.json').write_text(json.dumps(d.RESULTS,ensure_ascii=False,indent=2)+'\n')
    d.LOG.close()
