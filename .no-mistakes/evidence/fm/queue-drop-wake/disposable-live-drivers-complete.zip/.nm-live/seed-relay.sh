#!/usr/bin/env bash
set -eu
. "$PWD/bin/fm-x-lib.sh"
fmx_poll_shim_content "$FM_HOME" "$PWD" > "$FM_HOME/state/x-watch.check.sh"
chmod 700 "$FM_HOME/state/x-watch.check.sh"
