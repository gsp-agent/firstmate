import copy
import http.server
import json
import os
from pathlib import Path
import re
import socketserver
import ssl
import subprocess
import threading
import time

ROOT = Path.cwd()
LAB = ROOT / '.nm-live'
EVIDENCE = Path('/Users/dalecarman/.no-mistakes/evidence/01M51YY81T7RNEF2SS370MNK77')
LOG = (EVIDENCE / 'live-relay-liveness.log').open('w')
RESULTS = []
WORLD = None
CHILDREN = []

def emit(s):
    print(s, flush=True)
    LOG.write(s + '\n')
    LOG.flush()

def node(n, reason=None, event=None, queued=False, state='OPEN', created=None):
    return {'number': n, 'state': state, 'merged': state == 'MERGED',
            'isInMergeQueue': queued, 'createdAt': created or n, 'updatedAt': created or n,
            'isDraft': False, 'headRefOid': 'a' * 40,
            'timelineItems': {'nodes': [] if event is None else [{
                '__typename': 'RemovedFromMergeQueueEvent', 'id': event, 'reason': reason}]}}

class World:
    def __init__(self):
        self.repos = {}
        self.requests = []
        self.fail_repos = set()
        self.fail_cursor = None
        self.page_delay = 0
        self.poll_delay = 0
        self.page_hook = None
        self.poll_hook = None

    def read(self, request):
        q = request.get('query', '')
        v = request.get('variables', {})
        v = {k.lower(): value for k, value in v.items()}
        repo = str(v.get('owner', '')) + '/' + str(v.get('repo', v.get('name', '')))
        if 'pullRequests(' in q:
            cursor = v.get('cursor')
            order = re.search(r'orderBy\s*:\s*\{\s*field\s*:\s*(\w+)\s*,\s*direction\s*:\s*(\w+)', q)
            if order is None:
                raise ValueError('missing pull request order')
            order_field, direction = order.groups()
            record = {'type': 'page', 'repo': repo, 'cursor': cursor, 'order': order_field,
                      'at': time.time()}
            self.requests.append(record)
            if self.page_hook:
                self.page_hook(repo, cursor)
            if self.page_delay:
                time.sleep(self.page_delay)
            if repo in self.fail_repos or (self.fail_cursor is not None and cursor == self.fail_cursor):
                record['status'] = 503
                return 503, {'message': 'disposable endpoint: page unavailable'}
            key = {'CREATED_AT': 'createdAt', 'UPDATED_AT': 'updatedAt'}[order_field]
            pulls = sorted([p for p in self.repos.get(repo, {}).values() if p['state'] == 'OPEN'],
                           key=lambda p: p[key], reverse=direction == 'DESC')
            start = 0 if cursor is None else next(i+1 for i, p in enumerate(pulls) if 'c'+str(p['number']) == cursor)
            count = int(re.search(r'first\s*:\s*(\d+)', q).group(1))
            page = copy.deepcopy(pulls[start:start+count])
            record['numbers'] = [p['number'] for p in page]
            record['status'] = 200
            return 200, {'data': {'repository': {'pullRequests': {
                'nodes': page, 'pageInfo': {'hasNextPage': start + len(page) < len(pulls),
                    'endCursor': 'c'+str(page[-1]['number']) if page else None}}}}}
        if 'pullRequest(' in q:
            number = int(v.get('number', 0))
            record = {'type': 'poll', 'repo': repo, 'number': number, 'at': time.time(), 'status': 200}
            self.requests.append(record)
            if self.poll_hook:
                self.poll_hook(repo, number)
            if self.poll_delay:
                time.sleep(self.poll_delay)
            p = copy.deepcopy(self.repos[repo][number])
            if 'ADDED_TO_MERGE_QUEUE_EVENT' not in q:
                p['timelineItems']['nodes'] = [e for e in p['timelineItems']['nodes']
                    if e['__typename'] == 'RemovedFromMergeQueueEvent'][-1:]
            return 200, {'data': {'repository': {'pullRequest': p}}}
        self.requests.append({'type': 'unexpected', 'query': q})
        return 400, {'message': 'unsupported disposable GraphQL operation'}

TLS = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
TLS.load_cert_chain(str(LAB/'api.crt'), str(LAB/'api.key'))

class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_CONNECT(self):
        if self.path != 'api.github.com:443':
            self.send_error(502, 'this lab only serves api.github.com')
            return
        self.send_response(200, 'Connection established')
        self.end_headers()
        try:
            self.connection = TLS.wrap_socket(self.connection, server_side=True)
            self.rfile = self.connection.makefile('rb')
            self.wfile = self.connection.makefile('wb')
            self.close_connection = False
            self.handle_one_request()
        except (ssl.SSLError, ConnectionError):
            pass
        self.close_connection = True

    def do_POST(self):
        try:
            req = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
            status, data = WORLD.read(req)
        except Exception as exc:
            status, data = 500, {'message': str(exc)}
        payload = json.dumps(data, ensure_ascii=False).encode()
        try:
            self.send_response(status)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(payload)))
            self.send_header('Connection', 'close')
            self.end_headers()
            self.wfile.write(payload)
        except (ConnectionError, ssl.SSLError):
            pass

class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    def handle_error(self, *args):
        pass

SERVER = Server(('127.0.0.1', 0), Handler)
threading.Thread(target=SERVER.serve_forever, daemon=True).start()
PROXY = 'http://127.0.0.1:' + str(SERVER.server_port)

def environment(home):
    e = {k: v for k, v in os.environ.items() if not k.startswith(('FM_', 'GH_', 'GITHUB_', 'HERDR_', 'TASKS_AXI_', 'CMUX_'))
         and k not in ['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY','TMUX','TMUX_TMPDIR']}
    e.update(FM_HOME=str(home), FM_BACKEND='tmux', FM_CHECK_INTERVAL='0', FM_POLL='0.1',
             FM_HEARTBEAT='999999', FM_SIGNAL_GRACE='0',
             GH_CONFIG_DIR=str(LAB/'gh-config'), GH_TOKEN='fm-lab-disposable-no-production-access',
             HTTPS_PROXY=PROXY, HTTP_PROXY=PROXY, NO_PROXY='',
             SSL_CERT_FILE=str(LAB/'api.crt'), TMPDIR=str(LAB/'tmp'),
             TMUX=str(home/'no-server')+',0,0', GIT_CONFIG_GLOBAL='/dev/null', GIT_CONFIG_NOSYSTEM='1')
    return e

def run(home, args, *, check=True, timeout=30, extra=None, log=True):
    e = environment(home)
    if extra:
        e.update(extra)
    p = subprocess.run([str(a) for a in args], cwd=ROOT, env=e,
                       text=True, capture_output=True, timeout=timeout)
    if log:
        emit('$ ' + ' '.join(str(a).replace(str(ROOT)+'/', '') for a in args))
        emit('exit=' + str(p.returncode))
        if p.stdout.strip(): emit(p.stdout.rstrip())
        if p.stderr.strip(): emit(p.stderr.rstrip())
    if check and p.returncode:
        raise AssertionError(f'{args} failed: {p.stderr} {p.stdout}')
    return p

def create(name):
    global WORLD
    WORLD = World()
    home = LAB/name
    run(home, ['bin/fm-lab-home.sh', 'create', home], log=False)
    (home/'config/backend').write_text('tmux\n')
    # This registered check bounds quiet live cycles without replacing any
    # Firstmate code. Its output also proves that the complete check block ran.
    stop = home/'state/zz-lab-cycle.check.sh'
    stop.write_text('#!/usr/bin/env bash\nprintf "lab-cycle-complete\\n"\n')
    stop.chmod(0o700)
    run(home, ['bin/fm-check-register.sh','zz-lab-cycle'], log=False)
    emit('\n=== ' + name + ' ===')
    return home

def seed(home, task, repo, number, template=None):
    args = ['bash','.nm-live/seed-watch.sh',task,repo,str(number)]
    if template: args.append(template)
    run(home,args,log=False)

def watch(home, extra=None, timeout=60):
    return run(home,['bin/fm-watch.sh'],extra=extra,timeout=timeout)

def drain(home, ack=True):
    p = run(home,['bin/fm-wake-drain.sh'])
    if ack:
        m = re.search(r'--ack-through (\d+) --recovery-generation ([A-Za-z0-9._-]+)', p.stderr)
        assert m, 'missing durable acknowledgement command'
        run(home,['bin/fm-wake-drain.sh','--ack-through',m[1],'--recovery-generation',m[2]],log=False)
    return p.stdout

def has_drop(text, repo, number, reason):
    visible = json.dumps(reason or '', ensure_ascii=False)[1:-1]
    expected = f'dequeued https://github.com/{repo}/pull/{number} reason={visible}'
    assert sum(expected in line for line in text.splitlines()) == 1, f'missing or duplicate: {expected}'

def save_requests(name):
    (EVIDENCE/(name+'-api.json')).write_text(json.dumps(WORLD.requests, indent=2)+'\n')

def passed(name):
    RESULTS.append({'name':name,'result':'pass','live':True,'evidence':'live-queue-transcript.log','reason':''})
    emit('OBSERVED: ' + name)

def replay():
    h=create('replay')
    repo='groovejones/groove-sight-platform'
    specs={3941:'merge_conflict',3950:'merge_conflict',3939:'manual',4006:'merge_conflict',
           4017:'failed_checks',4111:'merge_conflict',4172:'manual',4183:'merge_conflict',
           4200:'merge_conflict',4308:'failed_checks'}
    WORLD.repos[repo] = {n:node(n,queued=True) for n in specs}
    seed(h,'gsp-vt2lz-p2',repo,4308)
    before=watch(h).stdout
    assert 'dequeued ' not in before
    drain(h)
    for n,reason in specs.items(): WORLD.repos[repo][n]=node(n,reason,'evt'+str(n))
    historical=LAB/'base-fm-pr-poll.sh'
    historical.write_bytes(subprocess.check_output(['git','show','20dcbf91520b1816663b81873ad67d0b93b3e4d6:bin/fm-pr-poll.sh'],cwd=ROOT))
    baseline=run(h,['bash',historical,'--validated','github',f'https://github.com/{repo}/pull/4308','github.com',repo,'4308'])
    assert 'dequeued ' not in baseline.stdout
    emit('BASELINE: open #4308 is outside the queue with failed_checks; the base poll emitted no notification.')
    got=watch(h).stdout
    for n,reason in specs.items(): has_drop(got,repo,n,reason)
    # Leave the notification queue unacknowledged, restart monitoring, then
    # read it twice. Every distinct PR must survive recovery and drain.
    watch(h)
    delivered=drain(h,ack=False)
    for n,reason in specs.items(): has_drop(delivered,repo,n,reason)
    drain(h)
    repeat=watch(h).stdout
    assert 'dequeued ' not in repeat
    drain(h)
    passed('Replay #4308 and all nine stranded pull requests; every PR and reason reaches the durable drain once across a restart')
    # A removal followed by an addition is quiet. A later distinct removal
    # of the same PR produces another notification.
    p=WORLD.repos[repo][4308]
    p['isInMergeQueue']=True
    p['timelineItems']['nodes'].append({'__typename':'AddedToMergeQueueEvent','id':'added4308'})
    assert 'dequeued ' not in watch(h).stdout
    drain(h)
    WORLD.repos[repo][4308]=node(4308,'ci_failure','evt4308second')
    has_drop(watch(h).stdout,repo,4308,'ci_failure')
    has_drop(drain(h),repo,4308,'ci_failure')
    assert 'dequeued ' not in watch(h).stdout
    drain(h)
    passed('Re-added and already handled removals stay quiet; a distinct later removal wakes again')
    save_requests('replay')

def reasons():
    h=create('reasons')
    repo='lab/reasons'
    reasons={2:None,3:'échec des vérifications',4:'failed "checks"\\path\nnext\tline\rcontrol\x01 event=not-the-id'}
    WORLD.repos[repo]={1:node(1,queued=True),**{n:node(n,r,'reason'+str(n)) for n,r in reasons.items()}}
    readded=node(5,'manual','old5')
    readded['timelineItems']['nodes'].append({'__typename':'AddedToMergeQueueEvent','id':'new5'})
    WORLD.repos[repo].update({5:readded,6:node(6,'merged','merge6'),7:node(7,'failed_checks','merge7',state='MERGED')})
    seed(h,'task-a',repo,1)
    out=watch(h).stdout
    delivered=drain(h)
    for n,r in reasons.items():
        has_drop(out,repo,n,r)
        has_drop(delivered,repo,n,r)
    for n in [5,6,7]: assert f'/pull/{n} reason=' not in delivered
    passed('Null, Unicode, quoted and multiline removal reasons arrive with exactly one escaping pass; merged and re-added PRs stay quiet')
    save_requests('reasons')

def pagination():
    h=create('pagination')
    repo='lab/pages'
    WORLD.repos[repo]={n:node(n,queued=True) for n in range(1,1002)}
    WORLD.repos[repo][2000]=node(2000,state='MERGED')
    seed(h,'task-a',repo,2000)
    changed=[]
    def update(repo,cursor):
        if cursor is not None and not changed:
            p=WORLD.repos[repo][1]
            p.update(updatedAt=1000000,isInMergeQueue=False)
            p['timelineItems']['nodes']=[{'__typename':'RemovedFromMergeQueueEvent','id':'evt-page11','reason':'failed_checks'}]
            changed.append(True)
    WORLD.page_hook=update
    has_drop(watch(h).stdout,repo,1,'failed_checks')
    has_drop(drain(h),repo,1,'failed_checks')
    pages=[r for r in WORLD.requests if r['type']=='page']
    assert len(pages)==11 and all(r['order']=='CREATED_AT' for r in pages)
    assert not (h/'state/task-a.pr-poll').exists()
    emit('PERSISTED RESULT: 11 pages / 1,001 open PRs; page-11 removal observed after page 1; last merged watch retired only after delivery.')
    passed('A PR updated after page 1 remains discoverable beyond 1,000 open PRs when the repository’s last armed PR merges')
    save_requests('pagination')

def retry(fault):
    h=create('retry-'+fault)
    repo='lab/retry'
    WORLD.repos[repo]={1:node(1,state='MERGED'),2:node(2,'failed_checks','evt-retry')}
    seed(h,'task-a',repo,1)
    seen=h/'state/merge-queue-sweep.seen'
    extra={}
    if fault=='page-failure': WORLD.fail_repos.add(repo)
    elif fault=='page-timeout': WORLD.page_delay=3; extra={'FM_CHECK_TIMEOUT':'1'}
    elif fault=='malformed-seen': seen.write_text('malformed\n'); seen.chmod(0o600)
    elif fault=='unreadable-seen': seen.write_text('fm-merge-queue-sweep-v1\n'); seen.chmod(0)
    elif fault=='unsafe-seen':
        target=h/'seen-target'
        target.write_text('external sentinel\n')
        seen.symlink_to(target)
    watch(h,extra=extra)
    drain(h)
    assert (h/'state/task-a.pr-poll').exists() and (h/'state/task-a.pr-poll-retirement').exists()
    emit('PERSISTED RESULT: failed scan retained the last repository sidecar and its retirement receipt.')
    WORLD.fail_repos.clear(); WORLD.page_delay=0
    if seen.is_symlink():
        assert seen.resolve().read_text()=='external sentinel\n'
        seen.unlink()
    elif seen.exists(): seen.chmod(0o600); seen.write_text('fm-merge-queue-sweep-v1\n')
    has_drop(watch(h).stdout,repo,2,'failed_checks')
    has_drop(drain(h),repo,2,'failed_checks')
    assert not (h/'state/task-a.pr-poll').exists()
    passed('Last merged watch survives '+fault+' and the next successful scan delivers the unarmed removal before retirement')
    save_requests('retry-'+fault)

def unrelated():
    h=create('later-polls')
    WORLD.repos={'lab/one':{1:node(1,'failed_checks','first')},'lab/two':{9:node(9,queued=True)}}
    seed(h,'task-a','lab/one',1); seed(h,'task-b','lab/two',9)
    seen=h/'state/merge-queue-sweep.seen'
    seen.write_text('malformed\n'); seen.chmod(0o600)
    for cycle in range(2):
        WORLD.repos['lab/one'][1]['timelineItems']['nodes'][0]['id']='later'+str(cycle)
        watch(h); drain(h)
        assert sum(r['type']=='poll' and r.get('repo')=='lab/two' for r in WORLD.requests)==cycle+1
        assert (h/'state/task-a.pr-poll').exists()
    emit('API RESULT: unrelated lab/two pull #9 was read in both cycles despite the malformed seen record.')
    passed('A malformed seen record fails the sweep while a later unrelated merge watch continues polling in the same cycle and after restart')
    save_requests('later-polls')

def completed_repo():
    h=create('completed-repo')
    WORLD.repos={'lab/a':{1:node(1,state='MERGED'),2:node(2,'failed_checks','evt-a')},
                 'lab/b':{1:node(1,state='MERGED'),2:node(2,'failed_checks','evt-b')}}
    seed(h,'task-a','lab/a',1); seed(h,'task-b','lab/b',1)
    WORLD.fail_repos.add('lab/b')
    out=watch(h).stdout
    has_drop(out,'lab/a',2,'failed_checks')
    has_drop(drain(h),'lab/a',2,'failed_checks')
    assert (h/'state/task-b.pr-poll').exists()
    WORLD.fail_repos.clear()
    has_drop(watch(h).stdout,'lab/b',2,'failed_checks')
    has_drop(drain(h),'lab/b',2,'failed_checks')
    passed('A completed repository publishes its removal even when another repository fails; the failed repository is retried')
    save_requests('completed-repo')

def slow(mode):
    h=create('slow-'+mode)
    repo='lab/slow'
    extra={'FM_CHECK_TIMEOUT':'10','FM_WATCHER_STALE_GRACE':'4','FM_WATCHER_STALL_BOUND':'4'}
    rearmed=[]
    began=time.monotonic()
    def rearm():
        p=run(h,['bin/fm-watch.sh'],extra=extra,check=False,timeout=10)
        assert p.returncode==0 and 'watcher: already running pid ' in p.stdout+p.stderr
        rearmed.append(True)
    if mode=='registered':
        WORLD.repos[repo]={n:node(n,queued=True) for n in range(1,9)}
        WORLD.repos[repo][8]=node(8,'failed_checks','evt-final')
        for n in range(1,9): seed(h,'task-'+str(n),repo,n)
        WORLD.poll_delay=1
        def hook(repo,n):
            if n==8: rearm()
        WORLD.poll_hook=hook
    else:
        WORLD.repos[repo]={n:node(n,queued=True) for n in range(1,602)}
        WORLD.repos[repo][1]=node(1,'failed_checks','evt-final')
        seed(h,'task-a',repo,601)
        WORLD.page_delay=1
        def hook(repo,cursor):
            if cursor=='c102': rearm()
        WORLD.page_hook=hook
    out=watch(h,extra=extra).stdout
    final=8 if mode=='registered' else 1
    has_drop(out,repo,final,'failed_checks'); has_drop(drain(h),repo,final,'failed_checks')
    assert rearmed and time.monotonic()-began>4
    passed('Slow '+mode+' reads keep the existing watcher alive through re-arm and deliver the final removal')
    save_requests('slow-'+mode)
