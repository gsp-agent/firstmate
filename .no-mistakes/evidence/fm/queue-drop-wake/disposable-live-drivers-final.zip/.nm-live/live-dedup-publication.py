import json
import publication_support as d

try:
    home=d.create('publication-lookup')
    repo='lab/publication-lookup'
    d.WORLD.repos[repo]={1:d.node(1,state='MERGED'),2:d.node(2,'failed_checks','evt-publication')}
    d.seed(home,'task-a',repo,1)
    seen=home/'state/merge-queue-sweep.seen'
    seen.write_text('fm-merge-queue-sweep-v1\n');seen.chmod(0o600)
    def corrupt(repo,cursor):
        seen.write_text('malformed-during-api-read\n')
        d.emit('TEST INPUT: the initially readable seen record becomes malformed during the real GitHub CLI page read, before publication lookup.')
    d.WORLD.page_hook=corrupt
    out=d.watch(home).stdout
    assert '/pull/2 reason=' not in out
    p=d.run(home,['bin/fm-pr-queue-sweep.sh','--contains',home/'state','evt-publication'],check=False)
    assert p.returncode==2
    assert (home/'state/task-a.pr-poll').exists()
    assert (home/'state/task-a.pr-poll-retirement').exists()
    d.drain(home)
    d.emit('PERSISTED RESULT: publication lookup status 2 preserved the repository sidecar and pending retirement after the otherwise successful API page.')
    d.WORLD.page_hook=None
    seen.write_text('fm-merge-queue-sweep-v1\n')
    d.has_drop(d.watch(home).stdout,repo,2,'failed_checks')
    d.has_drop(d.drain(home),repo,2,'failed_checks')
    assert not (home/'state/task-a.pr-poll').exists()
    d.passed('A deduplication lookup error after the API read preserves discovery; the next readable scan publishes the removal before retiring the last merged watch')
    d.save_requests('dedup-publication')
finally:
    d.SERVER.shutdown();d.SERVER.server_close()
    (d.EVIDENCE/'live-dedup-publication-scenarios.json').write_text(json.dumps(d.RESULTS,ensure_ascii=False,indent=2)+'\n')
    d.LOG.close()
