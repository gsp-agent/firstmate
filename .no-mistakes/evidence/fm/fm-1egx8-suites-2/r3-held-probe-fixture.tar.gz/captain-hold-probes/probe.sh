#!/usr/bin/env bash
mode=$1
printf '%s\n' "$mode" >> "$FM_HOME/$mode.attempts"
case "$mode" in
  failed) exit 1 ;;
  unknown) exec fm-test-missing-hold-probe ;;
  hung)
    printf '%s\n' "$$" > "$FM_HOME/probe.pid"
    trap '' TERM
    sleep 120 &
    printf '%s\n' "$!" > "$FM_HOME/probe-child.pid"
    wait
    ;;
  ready) test -f "$FM_HOME/probe-ready" ;;
esac
