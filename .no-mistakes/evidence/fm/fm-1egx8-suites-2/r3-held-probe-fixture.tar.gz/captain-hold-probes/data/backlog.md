## In flight

## Queued
- [ ] ordinary - Ordinary, "quoted" decision (repo: firstmate) (kind: captain) (since 2026-10-22) (hold: fm-hold-v1:Y2hvb3NlIHRoZSBuZXh0IGFjdGlvbg==) (hold-kind: captain) (hold-until: 2099-01-01)
  Captain hold set: 2026-10-22T08:36:41Z
- [ ] probe-failed - Probe failed, "quoted" (repo: firstmate) (kind: captain) (since 2026-10-22) (hold: fm-hold-v1:Y29tcGxldGUgdGhlIERhbGUgc3RlcA==) (hold-kind: captain)
  Captain hold set: 2026-10-22T08:37:29Z
  Decision owner: dale
  Hold timeout seconds: 3600
  Hold reason: complete the Dale step
  Hold probe: /Users/dalecarman/.no-mistakes/worktrees/a5e67f4ea77f/01M5H6NCKQJM2YC31BBNGTSVQQ/.test-phase-r3/tmp/fm-watch-triage-tests.fRpdVt/captain-hold-probes/probe.sh failed

- [ ] probe-unknown - Probe unknown, "quoted" (repo: firstmate) (kind: captain) (since 2026-10-22) (hold: fm-hold-v1:Y29tcGxldGUgdGhlIERhbGUgc3RlcA==) (hold-kind: captain)
  Captain hold set: 2026-10-22T08:38:09Z
  Decision owner: dale
  Hold timeout seconds: 3600
  Hold reason: complete the Dale step
  Hold probe: /Users/dalecarman/.no-mistakes/worktrees/a5e67f4ea77f/01M5H6NCKQJM2YC31BBNGTSVQQ/.test-phase-r3/tmp/fm-watch-triage-tests.fRpdVt/captain-hold-probes/probe.sh unknown

- [ ] probe-hung - Probe hung, "quoted" (repo: firstmate) (kind: captain) (since 2026-10-22) (hold: fm-hold-v1:Y29tcGxldGUgdGhlIERhbGUgc3RlcA==) (hold-kind: captain)
  Captain hold set: 2026-10-22T08:38:43Z
  Decision owner: dale
  Hold timeout seconds: 3600
  Hold reason: complete the Dale step
  Hold probe: /Users/dalecarman/.no-mistakes/worktrees/a5e67f4ea77f/01M5H6NCKQJM2YC31BBNGTSVQQ/.test-phase-r3/tmp/fm-watch-triage-tests.fRpdVt/captain-hold-probes/probe.sh hung

- [ ] probe-ready - Probe ready, "quoted" (repo: firstmate) (kind: captain) (since 2026-10-22)
  Resolution recorded by fm-captain-hold.
  Decision digest: 9fdda5e9cbc564ca84cf85e0188b57a2090a6eb8b4c21cc3bd5f0c3875ef21f7
  Resolution mode: probe-released

  Reconciliation evidence:
  Probe passed for the Dale step this hold waits on: /Users/dalecarman/.no-mistakes/worktrees/a5e67f4ea77f/01M5H6NCKQJM2YC31BBNGTSVQQ/.test-phase-r3/tmp/fm-watch-triage-tests.fRpdVt/captain-hold-probes/probe.sh ready

  Decision owner: dale
  Hold timeout seconds: 3600
  Hold reason: complete the Dale step
  Hold probe: /Users/dalecarman/.no-mistakes/worktrees/a5e67f4ea77f/01M5H6NCKQJM2YC31BBNGTSVQQ/.test-phase-r3/tmp/fm-watch-triage-tests.fRpdVt/captain-hold-probes/probe.sh ready

## Done
